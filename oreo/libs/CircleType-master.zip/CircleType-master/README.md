CircleType
========

A jQuery plugin that lets you curve type on the web

Demos: http://circletype.labwire.ca

