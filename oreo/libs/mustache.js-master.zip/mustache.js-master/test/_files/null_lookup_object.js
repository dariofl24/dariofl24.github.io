({
  "name": "David",
  "twitter": "@dasilvacontin",
  "fobject": [
    {
      "name": "Flor",
      "twitter": "@florrts"
    },
    {
      "name": "Miquel",
      "twitter": null
    },
    {
	"name": "Chris",
	"twitter": undefined
    }
  ],
  "favorites": {
    "color": "blue",
    "president": "Bush",
    "show": "Futurama"
  },
  "mascot": {
    "name": "Squid",
    "favorites": {
      "color": "orange",
      "president": undefined,
      "show": null
    }
  }
})
