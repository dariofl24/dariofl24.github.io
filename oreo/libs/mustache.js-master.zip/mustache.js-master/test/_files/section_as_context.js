({
  a_object: {
    title: 'this is an object',
    description: 'one of its attributes is a list',
    a_list: [
      {label: 'listitem1'},
      {label: 'listitem2'}
    ]
  }
})
